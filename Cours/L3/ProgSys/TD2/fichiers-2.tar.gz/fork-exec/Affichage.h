#ifndef _AFFICHAGE_H
#define _AFFICHAGE_H

#include "Shell.h"

extern void afficher_expr(Expression *e);

#endif
